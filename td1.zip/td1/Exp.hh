#ifndef EXP_HHttt
#define EXP_HHttt 
	#include <iostream>

	class Exp;
	class Bin;
	class Num;
	class Visitor
	{
	public:
		virtual double visitBin(const Bin& exp) = 0;
		virtual double visitNum(const Num& exp) = 0;
	};

	class Exp
	{
	public:
		Exp() {};
		Exp(double val):val_(val) {};
		Exp(const Exp& rhs) {};
		//Exp& operator=(const Exp& rhs) {};
	public:
		virtual ~Exp() {};
		virtual double accept(Visitor& v) const{return 0;};
		double val_;
	};

	class Bin : public Exp
	{
	public:
		Bin(char oper, Exp* lhs, Exp* rhs)
		: Exp(), oper_(oper), lhs_(lhs), rhs_(rhs)
		{};
		~Bin() { delete lhs_; delete rhs_; }
		double accept(Visitor& v) const {
			return v.visitBin(*this);
		}
		friend std::ostream& operator<<(std::ostream& o, const Bin& tree);
	public:
		char oper_; 
		Exp* lhs_; 
		Exp* rhs_;
	};

	class Num : public Exp
	{
	public:
		Num(double val)
		: Exp(val)
		{};
		friend std::ostream& operator<<(std::ostream& o, const Num& tree);
		double accept(Visitor& v) const {
			return v.visitNum(*this);
		}
	public:
	};

	class PrettyPrdoubleer : public Visitor
	{
	public:
		PrettyPrdoubleer(std::ostream& ostr)
		: ostr_(ostr) {};
		double visitBin(const Bin& e) {
			ostr_ << '('; e.lhs_->accept(*this);
			ostr_ << e.oper_; e.rhs_->accept(*this); ostr_ << ')';
			return 0;
		}
		double visitNum(const Num& e) {
			ostr_ << e.val_;
			return 0;
		}
	private:
		std::ostream& ostr_;
	};


	class Calculator : public Visitor
	{
	public:
		Calculator(){};
		double visitBin(const Bin& e) {
			if(e.oper_=='+') return e.lhs_->accept(*this)+e.rhs_->accept(*this);
			else if(e.oper_=='-') return e.lhs_->accept(*this)-e.rhs_->accept(*this); 
			else if(e.oper_=='*') return e.lhs_->accept(*this)*e.rhs_->accept(*this); 
			else if(e.oper_=='/') return e.lhs_->accept(*this)/e.rhs_->accept(*this); 
			return -1;
		}
		double visitNum(const Num& e) {
			return e.val_;
		}
	};

	inline std::ostream& operator<<(std::ostream& o, const Exp& e)
	{
		PrettyPrdoubleer prdoubleer(o);
		e.accept(prdoubleer);
		return o;
	}


	inline Exp* createNum(double i){
		return new Num(i);
	}

	inline Exp* createBin(char c, Exp* e1, Exp*e2){
		return new Bin(c,e1,e2);
	}

#endif