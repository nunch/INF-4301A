#include <iostream>
#include "Exp.hh"

int main(int argc, char const *argv[])
{
	Exp *truc = createBin('+',createNum(5),createNum(6));
	Calculator calc;
	truc->accept(calc);
	//std::cout<< truc->accept(calc)<<std::endl;
	std::cout << truc->accept(calc) << std::endl;
	return 0;
}