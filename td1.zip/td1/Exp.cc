	std::ostream& operator<<(std::ostream& o, const Exp& e)
	{
		PrettyPrinter printer(o);
		e.accept(printer);
		return o;
	}

	Exp* createNum(Exp* e){
		return new Num(e->val_);
	}

	Exp* createNum(int i){
		return new Num(i);
	}

	Exp* createBin(char c, Exp* e1, Exp*e2){
		return new Bin(c,e1,e2);
	}