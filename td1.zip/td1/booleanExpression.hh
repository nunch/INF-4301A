#ifndef BOOLEANEXPRESSION
#define BOOLEANEXPRESSION 
	
	#include "Exp.hh"

	class BooleanExpression
	{
	public:
		BooleanExpression(){};
		//~BooleanExpression(){};
	};

	class TrueEpression : public BooleanExpression
	{
	public:
		TrueEpression();
		//~TrueEpression();
		
	};

	class FalseExpression : public BooleanExpression
	{
	public:
		FalseExpression();
		//~FalseExpression();
		
	};

	class NoExpression : public BooleanExpression
	{
	public:
		NoExpression(BooleanExpression& op):op_(op){};
		//~NoExpression();
		
		BooleanExpression op_;
	};

	class BooleanOperation : public BooleanExpression
	{
	public:
		BooleanOperation(BooleanExpression& lhs, BooleanExpression& rhs):rhs_(rhs),lhs_(lhs){};
		//~BooleanOperation();
	
		BooleanExpression rhs_;
		BooleanExpression lhs_;
	};

	class AndOperation : public BooleanOperation
	{
	public:
		AndOperation(BooleanExpression& lhs, BooleanExpression& rhs):BooleanOperation(lhs,rhs){};
		//~AndOperation();
		
	};

	class OrOperation : public BooleanOperation
	{
	public:
		OrOperation(BooleanExpression& lhs, BooleanExpression& rhs):BooleanOperation(lhs,rhs){};
		//~OrOperation();
		
	};

	class Relation : public BooleanExpression
	{
	public:
		Relation(Exp& lhs, Exp& rhs):lhs_(lhs),rhs_(rhs){};
		//~Relation();
		
		Exp lhs_;
		Exp rhs_;
	};

	class Inf : public Relation
	{
	public:
		Inf(Exp& lhs, Exp& rhs):Relation(lhs,rhs){};
		//~Inf();
		
	};

	class Sup : public Relation
	{
	public:
		Sup(Exp& lhs, Exp& rhs):Relation(lhs,rhs){};
		//~Sup();
		
	};

	class Equal : public Relation
	{
	public:
		Equal(Exp& lhs, Exp& rhs):Relation(lhs,rhs){};
		//~Equal();
		
	};

#endif	